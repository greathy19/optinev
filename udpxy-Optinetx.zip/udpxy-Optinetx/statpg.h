/* @(#) HTML-page templates/generation for udpxy status page
 *
 * Copyright 2008-2011 Pavel V. Cherenkov (pcherenkov@gmail.com)
 *
 *  This file is part of udpxy.
 *
 *  udpxy is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  udpxy is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with udpxy.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef STATPG_H_0110081157_
#define STATPG_H_0110081157_

#ifdef __cplusplus
    extern "C" {
#endif

/* NB: strings are exposed in the header to be included
 *     by unit tests, yet made static to confine to a single unit */

static const char HTML_PAGE_HEADER[] =
        "HTTP/1.0 200 OK\n"
        "Content-type: text/html; charset=utf-8\n\n";

static const char* STAT_PAGE_BASE[] = {
    "<html>\n"
    "<head>\n"
    "<meta charset=\"utf-8\">\n"
    "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n"
    "<title>Optinetx - Estado del Servidor</title>\n"
    "<style type=\"text/css\">\n"
    "* {\n"
    "    margin: 0;\n"
    "    padding: 0;\n"
    "    box-sizing: border-box;\n"
    "}\n"
    "body {\n"
    "    background: linear-gradient(135deg, #f0f4f8 0%, #e8f1f8 100%);\n"
    "    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;\n"
    "    padding: 20px;\n"
    "    min-height: 100vh;\n"
    "}\n"
    "#bodyCon {\n"
    "    max-width: 900px;\n"
    "    margin: 0 auto;\n"
    "    background: white;\n"
    "    border-radius: 10px;\n"
    "    box-shadow: 0 4px 20px rgba(0, 102, 204, 0.15);\n"
    "    overflow: hidden;\n"
    "}\n"
    "#header {\n"
    "    background: linear-gradient(135deg, #0066cc 0%, #004a99 100%);\n"
    "    padding: 40px 30px;\n"
    "    color: white;\n"
    "    text-align: center;\n"
    "}\n"
    "#header h1 {\n"
    "    font-size: 36px;\n"
    "    margin-bottom: 10px;\n"
    "    font-weight: 700;\n"
    "    letter-spacing: 1px;\n"
    "}\n"
    "#header p {\n"
    "    font-size: 14px;\n"
    "    opacity: 0.95;\n"
    "    font-weight: 300;\n"
    "    letter-spacing: 0.5px;\n"
    "}\n"
    "#pgCont {\n"
    "    padding: 40px 30px;\n"
    "}\n"
    "h3 {\n"
    "    margin: 30px 0 20px 0;\n"
    "    font-size: 18px;\n"
    "    color: #0066cc;\n"
    "    font-weight: 600;\n"
    "    border-left: 4px solid #0066cc;\n"
    "    padding-left: 15px;\n"
    "    text-transform: uppercase;\n"
    "    letter-spacing: 0.5px;\n"
    "}\n"
    "h3:first-child {\n"
    "    margin-top: 0;\n"
    "}\n",

    "table {\n"
    "    width: 100%;\n"
    "    border-collapse: collapse;\n"
    "    margin: 20px 0;\n"
    "    background: white;\n"
    "}\n"
    "table:first-of-type {\n"
    "    margin-top: 0;\n"
    "}\n"
    "th {\n"
    "    background: linear-gradient(135deg, #0066cc 0%, #004a99 100%);\n"
    "    color: white;\n"
    "    padding: 15px 20px;\n"
    "    text-align: left;\n"
    "    font-weight: 600;\n"
    "    font-size: 13px;\n"
    "    text-transform: uppercase;\n"
    "    letter-spacing: 0.5px;\n"
    "    border: none;\n"
    "}\n"
    "td {\n"
    "    padding: 12px 20px;\n"
    "    border-bottom: 1px solid #e8f1f8;\n"
    "    font-size: 14px;\n"
    "    color: #333;\n"
    "}\n"
    "tr:hover td {\n"
    "    background-color: #f8fafc;\n"
    "}\n"
    ".proctabl th {\n"
    "    background: linear-gradient(135deg, #0066cc 0%, #004a99 100%);\n"
    "    color: white;\n"
    "}\n"
    ".proctabl tr:hover td {\n"
    "    background-color: #f0f7ff;\n"
    "}\n"
    ".proctabl tr.uneven {\n"
    "    background-color: #f8fafc;\n"
    "}\n"
    ".proctabl tr.uneven:hover td {\n"
    "    background-color: #f0f7ff;\n"
    "}\n",

    "#footer {\n"
    "    background: #f8fafc;\n"
    "    padding: 25px 30px;\n"
    "    text-align: center;\n"
    "    border-top: 1px solid #e8f1f8;\n"
    "    font-size: 11px;\n"
    "    color: #666;\n"
    "    line-height: 1.6;\n"
    "}\n"
    ".status-badge {\n"
    "    display: inline-block;\n"
    "    background: #28a745;\n"
    "    color: white;\n"
    "    padding: 8px 16px;\n"
    "    border-radius: 20px;\n"
    "    font-size: 12px;\n"
    "    font-weight: 600;\n"
    "    margin-top: 10px;\n"
    "}\n"
    "</style>\n"
    "</head>\n"
};
static const size_t LEN_STAT_PAGE_BASE = 3;

static const char STAT_PAGE_FMT1[] =
    "<body>\n"
    "<div id=\"bodyCon\">\n"
    "<div id=\"header\">\n"
    "<h1>OPTINETX</h1>\n"
    "<p>Servidor de Streaming Multicast</p>\n"
    "<span class=\"status-badge\">● EN LÍNEA</span>\n"
    "</div>\n"
    "<div id=\"pgCont\">\n"
    "<h3>Información del Servidor</h3>\n"
    "<table cellspacing=\"0\">\n"
    "<tr>\n"
    "    <th>ID de Proceso</th>\n"
    "    <th>Escuchando En</th>\n"
    "    <th>Puerta Multicast</th>\n"
    "    <th>Sesiones Activas</th>\n"
    "</tr>\n"
    "<tr>\n"
    "    <td>%d</td>\n"
    "    <td>%s:%d</td>\n"
    "    <td>%s</td>\n"
    "    <td>%d</td>\n"
    "</tr>\n"
    "</table>\n"
    "\n"
    "%s"  /* Tabla de clientes activos */
    "%s"  /* Información adicional */
    "</div>\n"
    "<div id=\"footer\">© 2024 Optinetx - Servidor Avanzado de Retransmisión Multicast</div>\n"
    "</div>\n"
    "</body>\n"
    "</html>\n";


static const char RST_PAGE_FMT1[] =
    "<body onload=\"body_onload();\">\n"
    "<div id=\"bodyCon\">\n"
    "<div id=\"header\">\n"
    "<h1>OPTINETX</h1>\n"
    "<p>Servicio en Reinicio...</p>\n"
    "</div>\n"
    "<div id=\"pgCont\">\n"
    "<h3>Información del Servidor</h3>\n"
    "<table cellspacing=\"0\">\n"
    "<tr>\n"
    "    <th>ID de Proceso</th>\n"
    "    <th>Escuchando En</th>\n"
    "    <th>Puerta Multicast</th>\n"
    "    <th>Sesiones Activas</th>\n"
    "</tr>\n"
    "<tr>\n"
    "    <td>%d</td>\n"
    "    <td>%s:%d</td>\n"
    "    <td>%s</td>\n"
    "    <td>%d</td>\n"
    "</tr>\n"
    "</table>\n"
    "\n"
    "%s"
    "%s"
    "</div>\n"
    "<div id=\"footer\">© 2024 Optinetx - Servidor Avanzado de Retransmisión Multicast</div>\n"
    "</div>\n"
    "</body>\n"
    "</html>\n";

static const char* ACLIENT_TABLE[] = {
    "<h3>Sesiones Activas</h3>\n"
    "<table cellspacing=\"0\" class=\"proctabl\">\n"
    "<tr><th>ID de Sesión</th><th>Dirección Origen</th><th>Destino del Flujo</th><th>Velocidad</th></tr>\n",
    "</table>\n" };


static const char* ACLIENT_REC_FMT[] = {
    "<tr><td>%d</td><td>%s:%d</td><td>%s:%d%s</td><td>%s</td></tr>\n",
    "<tr class=\"uneven\"><td>%d</td><td>%s:%d</td><td>%s:%d%s</td><td>%s</td></tr>\n" };


static const char REDIRECT_SCRIPT_FMT[] =
    "<script type=\"text/JavaScript\" language=\"Javascript\">"
    "function body_onload(){"
    "  var t=setTimeout(\"window.location = '../status/'\",%u)"
    "}"
    "</script>";

static const char REQUEST_GUIDE[] =
    "";


#ifdef __cplusplus
}
#endif

#endif /* STATPG_H_0110081157_ */

/* __EOF__ */
